// App shell: wires the chat API to the UI state, handles sends, errors,
// loading state, and clears the input after a successful send.
import { useState, useCallback } from 'react';
import { askQuestion } from './api/chatApi.js';
import Header from './components/Header.jsx';
import ChatWindow from './components/ChatWindow.jsx';
import QuestionInput from './components/QuestionInput.jsx';
import Footer from './components/Footer.jsx';

const MAX_QUESTION_LENGTH = 500;

export default function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const addBotMessage = useCallback((message) => {
    setMessages((prev) => [...prev, { id: Date.now(), ...message }]);
  }, []);

  const handleSend = useCallback(
    async (question) => {
      const trimmed = question.trim();
      if (!trimmed || trimmed.length > MAX_QUESTION_LENGTH) return;

      const userMessage = { id: Date.now(), type: 'user', text: trimmed };
      setMessages((prev) => [...prev, userMessage]);
      setLoading(true);
      setInput('');

      try {
        const data = await askQuestion(trimmed);
        addBotMessage({
          type: 'bot',
          text: data.answer,
          sources: data.sources,
          disclaimer: data.disclaimer,
        });
      } catch (err) {
        // Backend returned an error response (400 / 500).
        if (err.status) {
          addBotMessage({
            type: 'error',
            text: 'Something went wrong. Please try again.',
            detail: err.message || 'The server returned an error.',
          });
          return;
        }
        // Network failure (backend unreachable).
        addBotMessage({
          type: 'error',
          text: 'Cannot reach GST Sutra. Check that the backend is running.',
        });
      } finally {
        setLoading(false);
      }
    },
    [addBotMessage],
  );

  const handleChipSelect = useCallback(
    (question) => {
      setInput(question);
    },
    [],
  );

  return (
    <div className="app">
      <Header />
      <main>
        <ChatWindow
          messages={messages}
          loading={loading}
          input={input}
          onChipSelect={handleChipSelect}
          onSend={(q) => handleSend(q)}
        />
      </main>
      <QuestionInput
        value={input}
        onChange={(event) => setInput(event.target.value)}
        onSend={() => handleSend(input)}
        loading={loading}
      />
      <Footer />
    </div>
  );
}
