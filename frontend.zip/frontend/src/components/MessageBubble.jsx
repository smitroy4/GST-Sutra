// Renders a single chat message: user (right, navy) or bot (left, white card
// with saffron left border), plus sources and disclaimer under bot answers.
import SourceList from './SourceList.jsx';

export default function MessageBubble({ message }) {
  const isUser = message.type === 'user';
  const isError = message.type === 'error';

  return (
    <div className={`message ${isUser ? 'user' : 'bot'}`}>
      <div className={`message-avatar ${isUser ? 'user' : 'bot'}`}>
        {isUser ? 'You' : 'GS'}
      </div>
      <div>
        {!isUser && !isError && (
          <div className="message-bot-name">GST Sutra</div>
        )}
        <div className={`message-content ${isError ? 'message-error' : ''}`}>
          {message.text}
        </div>
        {!isUser && !isError && message.sources && (
          <SourceList sources={message.sources} />
        )}
        {!isUser && !isError && message.disclaimer && (
          <div className="disclaimer">{message.disclaimer}</div>
        )}
        {isError && message.detail && (
          <div className="disclaimer">{message.detail}</div>
        )}
      </div>
    </div>
  );
}
