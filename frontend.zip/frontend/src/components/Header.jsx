// Header banner: navy background, inline SVG logo mark, name, tagline,
// tricolor accent strip, and an unofficial-demo label.
export default function Header() {
  return (
    <header className="header" role="banner">
      <div className="header-inner">
        <div className="header-brand">
          <svg
            className="header-logo"
            viewBox="0 0 40 40"
            role="img"
            aria-label="GST Sutra logo"
          >
            {/* Document / ledger mark */}
            <rect x="6" y="5" width="22" height="30" rx="3" fill="none" stroke="currentColor" strokeWidth="2" />
            <line x1="10" y1="12" x2="20" y2="12" stroke="currentColor" strokeWidth="1.5" />
            <line x1="10" y1="16" x2="17" y2="16" stroke="currentColor" strokeWidth="1.5" />
            <line x1="10" y1="20" x2="21" y2="20" stroke="currentColor" strokeWidth="1.5" />
            <line x1="10" y1="24" x2="15" y2="24" stroke="currentColor" strokeWidth="1.5" />
            {/* Ashoka-style 24-spoke wheel in chakra blue */}
            <circle cx="30" cy="30" r="6" fill="none" stroke="var(--chakra-blue)" strokeWidth="2" />
            {[...Array(24)].map((_, i) => {
              const angle = (i * 15 * Math.PI) / 180;
              const x2 = 30 + 6 * Math.cos(angle);
              const y2 = 30 + 6 * Math.sin(angle);
              return (
                <line
                  key={i}
                  x1="30"
                  y1="30"
                  x2={x2}
                  y2={y2}
                  stroke="var(--chakra-blue)"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                />
              );
            })}
          </svg>
          <div className="header-text">
            <div className="header-name">GST Sutra</div>
            <div className="header-tagline">Dukaan ka GST, aasan bhasha mein.</div>
          </div>
        </div>
        <div className="header-meta">
          <div className="header-unofficial">
            Unofficial demo. Not affiliated with the Government of India.
          </div>
        </div>
      </div>
      <div className="tricolor" aria-hidden="true">
        <div className="tricolor-strip saffron" />
        <div className="tricolor-strip white" />
        <div className="tricolor-strip green" />
      </div>
    </header>
  );
}
