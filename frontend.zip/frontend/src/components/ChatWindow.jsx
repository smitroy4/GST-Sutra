// Chat area: welcome card + suggested questions when empty, message list,
// and a typing indicator while the backend is being called.
import MessageBubble from './MessageBubble.jsx';
import SuggestedQuestions from './SuggestedQuestions.jsx';
import FactsTicker from './FactsTicker.jsx';

export default function ChatWindow({
  messages,
  loading,
  input,
  onChipSelect,
  onSend,
}) {
  const hasMessages = messages.length > 0;

  return (
    <section className="chat-panel" aria-label="GST chat">
      <div className="chat-window">
        {/* GST facts ticker appears inside the chat box only while no answer
            has been generated (no messages yet). */}
        {!hasMessages && <FactsTicker />}
        {!hasMessages && (
          <div className="welcome-card">
            <div className="welcome-title">Welcome to GST Sutra</div>
            <div className="welcome-desc">
              Ask anything about GST rates, registration, returns or filing
              for your small shop. Answers are drawn from official GST
              documents and include sources.
            </div>
            <div className="suggested-list">
              <SuggestedQuestions questions={[
                'What is the GST rate on packaged snacks?',
                'Do I need GST registration if my turnover is low?',
                'What is the composition scheme?',
                'How do I file GSTR-3B and by when?',
              ]} onSelect={(q) => {
                onChipSelect(q);
                onSend(q);
              }} />
            </div>
          </div>
        )}
        {messages.map((message) => (
          <MessageBubble key={message.id} message={message} />
        ))}
        {loading && (
          <div className="typing" role="status" aria-live="polite">
            GST Sutra is checking the documents<span className="typing-dot" aria-hidden="true"></span><span className="typing-dot" aria-hidden="true"></span><span className="typing-dot" aria-hidden="true"></span>
          </div>
        )}
      </div>
    </section>
  );
}
