// Facts ticker: shows one GST fact at a time, rotates every 10 seconds
// with a soft fade. Pauses on hover/focus. Respects prefers-reduced-motion.
// Timer is cleaned up on unmount.
import { useEffect, useState, useRef } from 'react';
import { gstFacts } from '../data/gstFacts.js';

const ROTATE_MS = 10000;

export default function FactsTicker() {
  const [index, setIndex] = useState(0);
  const [exit, setExit] = useState(false);
  const timerRef = useRef(null);

  const fact = gstFacts[index % gstFacts.length];

  const next = () => {
    setExit(true);
    setTimeout(() => {
      setIndex((i) => (i + 1) % gstFacts.length);
      setExit(false);
    }, 600);
  };

  useEffect(() => {
    timerRef.current = setInterval(next, ROTATE_MS);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  return (
    <section className="ticker" aria-roledescription="GST fact ticker">
      <div className="ticker-inner">
        <div className="ticker-label">
          <span className="ticker-dot" aria-hidden="true"></span>
          GST fact
        </div>
        <div className="ticker-content">
          <div
            className={`ticker-item ${exit ? 'exit' : ''}`}
            tabIndex={0}
            aria-live="polite"
            role="region"
            aria-label="Current GST fact"
            onMouseEnter={() => clearInterval(timerRef.current)}
            onFocus={() => clearInterval(timerRef.current)}
            onMouseLeave={() => {
              timerRef.current = setInterval(next, ROTATE_MS);
            }}
            onBlur={() => {
              timerRef.current = setInterval(next, ROTATE_MS);
            }}
          >
            <div className="ticker-fact">{fact.text}</div>
            <div className="ticker-source">Source: {fact.source}</div>
          </div>
        </div>
      </div>
    </section>
  );
}
