// Renders a bot answer's sources. Empty fields are hidden instead of
// showing blank lines. Links open in a new tab with rel="noopener noreferrer".
export default function SourceList({ sources }) {
  if (!sources || sources.length === 0) {
    return null;
  }

  return (
    <section className="sources" aria-label="Sources">
      <div className="sources-title">Sources</div>
      {sources.map((source, idx) => {
        const parts = [];
        if (source.fileName) parts.push(source.fileName);
        if (source.heading) parts.push(source.heading);
        const extra = [];
        if (source.title) extra.push(source.title);
        if (source.url) {
          extra.push(
            <a
              key="url"
              href={source.url}
              target="_blank"
              rel="noopener noreferrer"
              className="source-link"
            >
              {source.title || 'Open source'}
            </a>,
          );
        }
        return (
          <div key={idx} className="source-item">
            {parts.length > 0 ? <strong>{parts.join(' — ')}</strong> : null}
            {extra.length > 0 ? (
              <span>
                {parts.length > 0 ? ' — ' : null}
                {extra.map((e, k) => (typeof e === 'string' ? e : <span key={k}>{e}</span>))}
              </span>
            ) : null}
          </div>
        );
      })}
    </section>
  );
}
