// Suggested question chips. Clicking one fills the input and sends it.
export default function SuggestedQuestions({ questions, onSelect }) {
  return (
    <div role="group" aria-label="Suggested questions">
      {questions.map((question, idx) => (
        <button
          key={idx}
          type="button"
          className="suggested-chip"
          onClick={() => onSelect(question)}
        >
          {question}
        </button>
      ))}
    </div>
  );
}
