// Input bar: text input, live character count (x / 500), send button.
// Enter sends. Disabled while loading or when input is empty / above 500 chars.
export default function QuestionInput({
  value,
  onChange,
  onSend,
  loading,
}) {
  const max = 500;
  const overLimit = value.length > max;

  const handleKeyDown = (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      onSend();
    }
  };

  return (
    <div className="input-bar">
      <div className="input-inner">
        <div className="input-row">
          <input
            className="input-field"
            type="text"
            placeholder="Ask a GST question..."
            value={value}
            onChange={onChange}
            onKeyDown={handleKeyDown}
            aria-label="GST question input"
            maxLength={max}
            disabled={loading}
          />
          <span className={`char-count ${overLimit ? 'over-limit' : ''}`}>
            {value.length} / {max}
          </span>
          <button
            type="button"
            className="send-button"
            disabled={loading || value.trim().length === 0 || overLimit}
            onClick={onSend}
            aria-label="Send question"
          >
            &rarr;
          </button>
        </div>
      </div>
    </div>
  );
}
