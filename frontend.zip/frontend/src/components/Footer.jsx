// Page footer with the unofficial demo note.
export default function Footer() {
  return (
    <footer className="footer" role="contentinfo">
      <div className="footer-inner">
        <div className="footer-note">
          <strong>GST Sutra</strong> is an unofficial demo for educational
          purposes only. It is not affiliated with, nor endorsed by, the
          Government of India, CBIC, or the GST Portal. Answers may be
          incomplete or incorrect; always verify against official GST sources
          and consult a tax professional for decisions affecting your business.
        </div>
      </div>
    </footer>
  );
}
