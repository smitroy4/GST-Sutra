// GST facts shown in the facts ticker.
// Every fact below is verifiable from the backend source documents
// (backend/src/main/resources/docs/*.md). If you add a fact you cannot
// verify, leave the text as a placeholder and add a TODO comment.
export const gstFacts = [
  {
    text: 'Packaged savoury snacks such as namkeen, bhujia and mixture (HSN 2106 90) attract 5% GST (2.5% CGST + 2.5% SGST), reduced from 12% effective 22 September 2025.',
    source: 'gst-rates.md',
  },
  {
    text: 'Notebooks, exercise books, pencils, crayons, erasers and pencil sharpeners attract Nil (0%) GST under the revised rates effective 22 September 2025.',
    source: 'gst-rates.md',
  },
  {
    text: 'A small shop selling only goods generally needs GST registration if annual turnover exceeds ₹40 lakh (₹20 lakh for services; ₹10 lakh in some special-category states).',
    source: 'registration.md',
  },
  {
    text: 'You must apply for GST registration within 30 days from the date you become liable to register.',
    source: 'registration.md',
  },
  {
    text: 'Under the Composition Scheme, traders pay 1% tax (0.5% CGST + 0.5% SGST) when yearly turnover is up to ₹1.5 crore (₹75 lakh in special-category states).',
    source: 'composition-scheme.md',
  },
  {
    text: 'Composition dealers cannot collect GST from customers, cannot claim Input Tax Credit, and cannot make inter-State sales.',
    source: 'composition-scheme.md',
  },
  {
    text: 'Monthly GSTR-3B is due by the 20th of the following month; quarterly QRMP filers file by the 22nd or 24th depending on the state.',
    source: 'filing-deadlines.md',
  },
  {
    text: 'There is no late fee on FORM GST CMP-08 or PMT-06 challans.',
    source: 'filing-deadlines.md',
  },
  // TODO: Verify this fact against invoicing-basics.md before enabling:
  // {
  //   text: 'Placeholder fact: no invoice needed per sale below ₹200 to an unregistered buyer who does not ask; one consolidated daily invoice suffices.',
  //   source: 'invoicing-basics.md',
  // },
];
